package Proxy.selfExample_InternetProxy;

public interface Internet {
	
	void connectToHost(String url);
	
}
