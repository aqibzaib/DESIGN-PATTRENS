package Flyweight;



public interface Shape {
    void draw();
}
